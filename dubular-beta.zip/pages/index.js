export default function Home() {
  return <h1>Dubular is live!</h1>;
}}
