
          window.__NEXT_REGISTER_PAGE('/api/assistant/avatar', function() {
            var comp = module.exports=webpackJsonp([11],{146:function(e,t,n){"use strict";function u(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(t,"__esModule",{value:!0});var r=n(29),a=u(r),s=n(26),o=u(s);t.default=function(){function e(e,n){return t.apply(this,arguments)}var t=(0,o.default)(a.default.mark(function e(t,n){return a.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:n.status(200).json({message:"Avatar API"});case 1:case"end":return e.stop()}},e,this)}));return e}()},204:function(e,t,n){e.exports=n(146)}},[204]);
            return { page: comp.default }
          })
        