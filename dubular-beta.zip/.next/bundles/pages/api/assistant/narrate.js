
          window.__NEXT_REGISTER_PAGE('/api/assistant/narrate', function() {
            var comp = module.exports=webpackJsonp([9],{148:function(e,t,n){"use strict";function r(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(t,"__esModule",{value:!0});var u=n(29),a=r(u),s=n(26),o=r(s);t.default=function(){function e(e,n){return t.apply(this,arguments)}var t=(0,o.default)(a.default.mark(function e(t,n){return a.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:n.status(200).json({message:"Narrate API"});case 1:case"end":return e.stop()}},e,this)}));return e}()},206:function(e,t,n){e.exports=n(148)}},[206]);
            return { page: comp.default }
          })
        