
          window.__NEXT_REGISTER_PAGE('/api/db/save', function() {
            var comp = module.exports=webpackJsonp([7],{150:function(e,t,n){"use strict";function u(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(t,"__esModule",{value:!0});var r=n(29),s=u(r),a=n(26),o=u(a);t.default=function(){function e(e,n){return t.apply(this,arguments)}var t=(0,o.default)(s.default.mark(function e(t,n){return s.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:n.status(200).json({message:"Save to DB"});case 1:case"end":return e.stop()}},e,this)}));return e}()},208:function(e,t,n){e.exports=n(150)}},[208]);
            return { page: comp.default }
          })
        