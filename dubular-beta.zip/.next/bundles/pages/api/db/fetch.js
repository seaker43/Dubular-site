
          window.__NEXT_REGISTER_PAGE('/api/db/fetch', function() {
            var comp = module.exports=webpackJsonp([8],{149:function(e,t,n){"use strict";function u(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(t,"__esModule",{value:!0});var r=n(29),s=u(r),o=n(26),a=u(o);t.default=function(){function e(e,n){return t.apply(this,arguments)}var t=(0,a.default)(s.default.mark(function e(t,n){return s.default.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:n.status(200).json({message:"Fetch from DB"});case 1:case"end":return e.stop()}},e,this)}));return e}()},207:function(e,t,n){e.exports=n(149)}},[207]);
            return { page: comp.default }
          })
        