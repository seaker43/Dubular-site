
          window.__NEXT_REGISTER_PAGE('/', function() {
            var comp = module.exports=webpackJsonp([4],{153:function(e,t,u){"use strict";function n(){return r.default.createElement("h1",null,"Dubular is live!")}Object.defineProperty(t,"__esModule",{value:!0}),t.default=n;var l=u(14),r=function(e){return e&&e.__esModule?e:{default:e}}(l)},211:function(e,t,u){e.exports=u(153)}},[211]);
            return { page: comp.default }
          })
        